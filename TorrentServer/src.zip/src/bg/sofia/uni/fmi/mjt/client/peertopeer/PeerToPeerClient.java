package bg.sofia.uni.fmi.mjt.client.peertopeer;

import bg.sofia.uni.fmi.mjt.peerinfo.PeerInfo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class PeerToPeerClient implements Runnable {
    private PeerInfo peerInfo;
    private String pathToDownload;
    private String pathToSave;

    public PeerToPeerClient(String username, int port, String pathToDownload, String pathToSave) {
     //   this.username = username;
     //   this.port = port;
        this.pathToDownload = pathToDownload;
        this.pathToSave = pathToSave;
    }

    public PeerToPeerClient(int port) {
        // this.username = username;
        //  this.port = port;
        // this.pathToDownload = pathToDownload;
        //  this.pathToSave = pathToSave;
    }

    public PeerToPeerClient(PeerInfo peerInfo) {
        this.peerInfo = peerInfo;
    }

    @Override
    public void run() {
        try (Socket socket = new Socket("localhost", peerInfo.port());
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            writer.println("HEY");
            String reply = reader.readLine();
            System.out.println(reply);

        } catch (IOException e) {
            throw new RuntimeException("There is a problem with the network communication", e);
        }
    }
}
