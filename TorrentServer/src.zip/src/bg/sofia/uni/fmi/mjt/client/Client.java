package bg.sofia.uni.fmi.mjt.client;

import bg.sofia.uni.fmi.mjt.client.peertopeer.PeerToPeerClient;
import bg.sofia.uni.fmi.mjt.client.peertopeer.PeerToPeerServer;
import bg.sofia.uni.fmi.mjt.client.update.RepeatUpdate;
import bg.sofia.uni.fmi.mjt.peerinfo.PeerInfo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static bg.sofia.uni.fmi.mjt.server.ClientHandler.DOWNLOAD_MATCHER;

public class Client {
    private static final int SERVER_PORT = 4122;
    private static final String DECLINE_MATCHER = "quit";
    private String username;
    private List<PeerInfo> peers;
    private PeerInfo peer;

    public Client(String username) {
        this.username = username;
        peers = new ArrayList<>();
    }

    private PeerInfo connectToPeerServer(String line) {
        String[] tokens = line.split(" ");
        String username = tokens[1];
        for (PeerInfo peerInfo : peers) {
            if (peerInfo.host().equalsIgnoreCase(username)) {
                return peerInfo;
            }
        }
        return null; //
    }

    public static String enterUsername(PrintWriter writer, BufferedReader reader, Scanner scanner) throws IOException {
        System.out.println("Please Enter your username:");
        System.out.print("=> ");
        String message = scanner.nextLine();
        writer.println(message);
        String reply = reader.readLine();
        System.out.println(reply);
        return reply;
    }

    public static boolean downloadFromPeer(String message) {
        Pattern pattern = Pattern.compile(DOWNLOAD_MATCHER);
        Matcher matcher = pattern.matcher(message);
        return matcher.matches();
    }

    public static boolean disconnectClient(String message) {
        Pattern pattern = Pattern.compile(DECLINE_MATCHER);
        Matcher matcher = pattern.matcher(message);
        return matcher.matches();
    }

    public static void runningClient(Scanner scanner, PrintWriter writer, BufferedReader reader, Client client)
            throws IOException {
        while (true) {
            System.out.print("=> ");
            String message = scanner.nextLine();
            if (disconnectClient(message)) {
                System.out.println("Disconnected from the server");
                break;
            }
            if (downloadFromPeer(message)) {
                Thread.ofVirtual().start(new PeerToPeerClient(client.connectToPeerServer(message)));
                continue;
            }
            writer.println(message);
            String reply = reader.readLine();
            System.out.println(reply);
        }
    }

    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", SERVER_PORT);
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             Scanner scanner = new Scanner(System.in)) {
            synchronized (socket) {
                System.out.println("Connected to the server.");
                Client client = new Client(enterUsername(writer, reader, scanner));
                PeerToPeerServer p2pServer = new PeerToPeerServer(0);
                Thread.ofVirtual().start(p2pServer);
                client.peer = new PeerInfo(client.username, socket.getInetAddress().toString(), p2pServer.getPort());
                //    Thread.ofVirtual().start(new UpdatePeerInfoInServer(client.peer, socket));
                Thread.ofVirtual().start(new RepeatUpdate(client.peers, socket));
                runningClient(scanner, writer, reader, client);
            }
        } catch (IOException e) {
            throw new RuntimeException("There is a problem with the network communication", e);
        }
    }
}
