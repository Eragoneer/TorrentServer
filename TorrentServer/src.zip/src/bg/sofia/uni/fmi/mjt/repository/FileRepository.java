package bg.sofia.uni.fmi.mjt.repository;

import bg.sofia.uni.fmi.mjt.response.Response;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;

public class FileRepository {
    private HashSet<Path> filePath;

    public FileRepository() {
        filePath = new HashSet<>();
    }

    public Response register(String username, Collection<String> paths) {
        /** MAYBE EXCEPTIONS*/
        Collection<Path> validRegistrations = new LinkedList<>();
        for (String pathString : paths) {
            Path path = Paths.get(pathString);
            if (!filePath.contains(path)) {
                validRegistrations.add(path);
                filePath.add(path);
            }
        }
        return Response.register(username, validRegistrations);
    }

    public Response unregister(String username, Collection<String> paths) {
        /** MAYBE EXCEPTIONS*/
        Collection<Path> validUnregistrations = new LinkedList<>();
        for (String pathString : paths) {
            Path path = Paths.get(pathString);
            if (filePath.contains(path)) {
                validUnregistrations.add(path);
                filePath.remove(path);
            }
        }
        return Response.unregister(username, validUnregistrations);
    }

    public Response listFiles(String username) {
        /** MAYBE EXCEPTIONS*/
        return Response.listFiles(username, filePath);
    }


//
//    public Response unregister(Path path) {
//        if (filePath.contains(path)) {  /** MAYBE EXCEPTIONS*/
//            filePath.remove(path);
//        }
//    }
}
