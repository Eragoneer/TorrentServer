package bg.sofia.uni.fmi.mjt.server;

import bg.sofia.uni.fmi.mjt.peerinfo.PeerInfo;
import bg.sofia.uni.fmi.mjt.repository.FileRepository;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ClientHandler implements Runnable {
    public static Set<ClientHandler> clients = new LinkedHashSet<>();
    private Socket socket;
    private FileRepository userFilePaths;
    private String username;
    private PeerInfo peerInfo;

    public static final String REGISTER_MATCHER = "\\bregister\\s\\S+\\s(\\S+,\\s)*\\S+\\b";
    public static final String UNREGISTER_MATCHER = "\\bunregister\\s\\S+\\s(\\S+,\\s)*\\S+\\b";
    public static final String LIST_ALL_MATCHER = "\\blist-files\\b";
    public static final String UPDATE_MATCHER = "\\bupdate\\b";
    public static final String DOWNLOAD_MATCHER = "\\bdownload\\s\\S+\\s\\S+\\s\\S+\\b";
    public static final String PEER_INFO_MATCHER = "\\bpeer\\s\\S+\\s\\S+\\s\\S+\\b";

    public ClientHandler(Socket socket) {
        this.socket = socket;
        userFilePaths = new FileRepository();
    }

    private void setUsername(String username) {
        /** Check for exceptions */
        /** Check for duplicates */
        this.username = username;
    }

    private void askClientForUsername(BufferedReader in, PrintWriter out) throws IOException {
        String inputLine;
        if ((inputLine = in.readLine()) != null) {
            System.out.println("Username received from client: " + inputLine);
            setUsername(inputLine);
            out.println("your username is: " + inputLine);
        }
    }

    public boolean matchCommands(String inputLine, String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(inputLine);
        return matcher.matches();
    }

    public List<String> formatCommandLine(String inputLine) {
        return Arrays.stream(inputLine.split(",*\\s"))
                .skip(1)
                .toList();
    }

    public String mapAllUserFiles() {
        Iterator<ClientHandler> it = clients.iterator();
        StringBuilder stringBuilder = new StringBuilder();
        if (it.hasNext()) {
            ClientHandler clientHandler = it.next();
            stringBuilder.append(clientHandler.userFilePaths.listFiles(clientHandler.username));
        }
        while (it.hasNext()) {
            ClientHandler clientHandler = it.next();
            stringBuilder.append(";")
                    .append(clientHandler.userFilePaths.listFiles(clientHandler.username));
        }
        return stringBuilder.toString();
    }

    public String mapAllClientInfo() {
        Iterator<ClientHandler> it = clients.iterator();
        StringBuilder stringBuilder = new StringBuilder();
        if (it.hasNext()) {
            ClientHandler clientHandler = it.next();
            stringBuilder.append(clientHandler.username)
                    .append(" - ").append(clientHandler.socket.getInetAddress())
                    .append(":")
                    .append(clientHandler.socket.getPort());
        }
        while (it.hasNext()) {
            ClientHandler clientHandler = it.next();
            stringBuilder.append(";")
                    .append(clientHandler.username)
                    .append(" - ").append(clientHandler.socket.getInetAddress())
                    .append(":").append(clientHandler.socket.getPort());
        }
        return stringBuilder.toString();
    }

    public String initPeerInfo(String inputLine) {
        List<String> list = formatCommandLine(inputLine);
        peerInfo = new PeerInfo(list.get(0), list.get(1), Integer.parseInt(list.get(2)));
        return "Peer Info updated";
    }

    public String commands(String inputLine) {
        if (matchCommands(inputLine, REGISTER_MATCHER)) {
            List<String> list = formatCommandLine(inputLine);
            return userFilePaths.register(list.get(0),
                    list.subList(1, list.size())).toString();
        }
        if (matchCommands(inputLine, UNREGISTER_MATCHER)) {
            List<String> list = formatCommandLine(inputLine);
            return userFilePaths.unregister(list.get(0),
                    list.subList(1, list.size())).toString();
        }
        if (matchCommands(inputLine, LIST_ALL_MATCHER)) {
            return mapAllUserFiles();
        }
        if (matchCommands(inputLine, UPDATE_MATCHER)) {
            return mapAllClientInfo();
        }
        if (matchCommands(inputLine, PEER_INFO_MATCHER)) {
            return initPeerInfo(inputLine);
        }
        return "unknown command";
    }

    @Override
    public void run() {
        try (PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
            clients.add(this);
            String inputLine;
            askClientForUsername(in, out);
            while ((inputLine = in.readLine()) != null) {
                System.out.println("Message received from client: " + inputLine);
                out.println(commands(inputLine));
                // format command and input into the fileRepository
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
            /** Save exceptions stacktreace in a local file and ,local message needs to be user friendly*/
        } finally {
            try {
                clients.remove(this);
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
