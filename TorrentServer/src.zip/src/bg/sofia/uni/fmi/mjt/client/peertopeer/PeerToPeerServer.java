package bg.sofia.uni.fmi.mjt.client.peertopeer;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PeerToPeerServer implements Runnable {
    private static final int MAX_EXECUTOR_THREADS = 10;

    private int serverPort;

    public PeerToPeerServer(int port) {
        serverPort = port;
    }

    private void setServerPort(int port) {
        this.serverPort = port;
    }

    public Integer getPort() {
        return this.serverPort;
    }

    @Override
    public void run() {
        ExecutorService executor = Executors.newFixedThreadPool(MAX_EXECUTOR_THREADS);

        try (ServerSocket serverSocket = new ServerSocket(serverPort)) {

            Socket clientSocket;
            while (true) {
                clientSocket = serverSocket.accept();
                System.out.println("Accepted connection request from client "
                        + clientSocket.getInetAddress() + " Port: " + clientSocket.getPort());
                PeerToPeerClientHandler clientHandler = new PeerToPeerClientHandler(clientSocket);
                executor.execute(clientHandler);
            }
        } catch (IOException e) {
            throw new RuntimeException("Issue with Thread pool", e);
        }
    }
}
