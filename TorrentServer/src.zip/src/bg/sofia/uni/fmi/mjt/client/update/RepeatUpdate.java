package bg.sofia.uni.fmi.mjt.client.update;

import bg.sofia.uni.fmi.mjt.peerinfo.PeerInfo;

import java.net.Socket;
import java.util.List;

public class RepeatUpdate implements Runnable {
    private List<PeerInfo> peerInfos;
    private Socket socket;
    private static final Integer THREAD_SLEEP = 30000;

    public RepeatUpdate(List<PeerInfo> peerInfos, Socket socket) {
        this.peerInfos = peerInfos;
        this.socket = socket;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.ofVirtual().start(new UpdatePeerInfo(peerInfos, socket));
                Thread.sleep(THREAD_SLEEP);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
