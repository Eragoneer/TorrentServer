package bg.sofia.uni.fmi.mjt.client.update;

import bg.sofia.uni.fmi.mjt.peerinfo.PeerInfo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class UpdatePeerInfoInServer implements Runnable {

    private Socket socket;
    private PeerInfo peerInfo;

    public UpdatePeerInfoInServer(PeerInfo peerInfo, Socket socket) {
        this.peerInfo = peerInfo;
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out.println("peer " + peerInfo.host() + " " + peerInfo.ip() + " " + peerInfo.port());
            in.readLine();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            /** Save exceptions stacktreace in a local file and ,local message needs to be user friendly*/
        }
    }
}
