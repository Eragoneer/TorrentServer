package bg.sofia.uni.fmi.mjt.response;

import java.nio.file.Path;
import java.util.Collection;
import java.util.Iterator;

public record Response(Status status, String username, Collection<Path> filePaths) {
    private enum Status {
        REGISTER("Registered"),
        UNREGISTER("not found"),
        LIST_FILES("list files"),
        DOWNLOAD("download");

        private String name;

        Status(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }

    public static Response register(String username, Collection<Path> filePaths) {
        return new Response(Status.REGISTER, username, filePaths);
    }

    public static Response unregister(String username, Collection<Path> filePaths) {
        return new Response(Status.UNREGISTER, username, filePaths);
    }

    public static Response listFiles(String username, Collection<Path> filePaths) {
        return new Response(Status.LIST_FILES, username, filePaths);
    }

    public static Response downloadFile(String username, Collection<Path> filePaths) {
        return new Response(Status.LIST_FILES, username, filePaths);
    }

    private String iteratePathCollection() {
        StringBuilder stringBuilder = new StringBuilder();
        Iterator<Path> it = filePaths.iterator(); // check for iterator
        if (it.hasNext()) {
            stringBuilder.append(it.next());
        }
        while (it.hasNext()) {
            stringBuilder.append(", ").append(it.next());
        }
        return stringBuilder.toString();
    }

    private String formatRegister() {
        return String.format("Registered Files from %s are:%s", username, iteratePathCollection());
    }

    private String formatUnregister() {
        return String.format("Unregistered Files from %s are:%s", username, iteratePathCollection());
    }

    private String formatDownload() {
        Iterator<Path> it = filePaths.iterator();
        String from = it.next().toString(); // check for iterator
        String to = it.next().toString();
        return String.format("From user %s is being downloaded file %s to %s", username, from, to);
    }

    private String formatListFiles() {
        return String.format("All Files from %s are:%s", username, iteratePathCollection());
    }

    @Override
    public String toString() {
        return switch (status) {
            case REGISTER -> formatRegister();
            case UNREGISTER -> formatUnregister();
            case DOWNLOAD -> formatDownload();
            case LIST_FILES -> formatListFiles();
        };
    }

}
