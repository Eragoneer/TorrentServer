package bg.sofia.uni.fmi.mjt.peerinfo;

public record PeerInfo(String host, String ip, Integer port) {

}
